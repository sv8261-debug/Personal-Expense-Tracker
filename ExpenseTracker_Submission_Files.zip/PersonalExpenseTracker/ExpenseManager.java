import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;

public class ExpenseManager extends JFrame {
    private static final String DB_URL = "jdbc:oracle:thin:@//HOST:1521/SERVICE_NAME";
    private static final String DB_USER = "YOUR_USERNAME";
    private static final String DB_PASSWORD = "YOUR_PASSWORD";

    private Connection connection;
    private final JTextField dateField = new JTextField(LocalDate.now().toString(), 12);
    private final JComboBox<String> categoryBox = new JComboBox<>(
            new String[]{"Food", "Travel", "Education", "Shopping", "Bills", "Other"});
    private final JTextField descriptionField = new JTextField(16);
    private final JTextField amountField = new JTextField(10);
    private final JTextField monthField = new JTextField(LocalDate.now().toString().substring(0, 7), 7);
    private final JTextField idField = new JTextField(6);
    private final JLabel totalLabel = new JLabel("Monthly total: 0.00");
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Date", "Category", "Description", "Amount"}, 0) {
        @Override public boolean isCellEditable(int row, int col) { return false; }
    };
    private final JTable table = new JTable(model);

    public ExpenseManager() {
        super("Personal Expense Tracker");
        buildUI();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        connectToDatabase();
    }

    private void buildUI() {
        JPanel form = new JPanel(new GridLayout(3, 4, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Expense Details"));
        form.add(new JLabel("Expense ID (for update/delete):")); form.add(idField);
        form.add(new JLabel("Date (YYYY-MM-DD):")); form.add(dateField);
        form.add(new JLabel("Category:")); form.add(categoryBox);
        form.add(new JLabel("Description:")); form.add(descriptionField);
        form.add(new JLabel("Amount:")); form.add(amountField);
        form.add(new JLabel("Month (YYYY-MM):")); form.add(monthField);

        JButton add = new JButton("Add");
        JButton view = new JButton("View Month");
        JButton update = new JButton("Update Selected ID");
        JButton delete = new JButton("Delete Selected ID");
        JButton categories = new JButton("Category Totals");
        add.addActionListener(e -> addExpense());
        view.addActionListener(e -> viewMonth());
        update.addActionListener(e -> updateExpense());
        delete.addActionListener(e -> deleteExpense());
        categories.addActionListener(e -> categoryTotals());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 8));
        buttons.add(add); buttons.add(view); buttons.add(update); buttons.add(delete); buttons.add(categories);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                idField.setText(model.getValueAt(r, 0).toString());
                dateField.setText(model.getValueAt(r, 1).toString());
                categoryBox.setSelectedItem(model.getValueAt(r, 2).toString());
                descriptionField.setText(model.getValueAt(r, 3).toString());
                amountField.setText(model.getValueAt(r, 4).toString());
            }
        });
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(totalLabel);
        setLayout(new BorderLayout(10, 10));
        add(form, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel south = new JPanel(new BorderLayout());
        south.add(buttons, BorderLayout.NORTH); south.add(bottom, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);
        ((JComponent)getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    private void connectToDatabase() {
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            JOptionPane.showMessageDialog(this, "Connected to Oracle database.");
        } catch (SQLException ex) {
            connection = null;
            JOptionPane.showMessageDialog(this,
                    "GUI opened, but Oracle is not connected.\nUpdate DB_URL, DB_USER, DB_PASSWORD and add ojdbc driver.\n\nDetails: " + ex.getMessage(),
                    "Database connection unavailable", JOptionPane.WARNING_MESSAGE);
        }
    }

    private boolean ready() {
        if (connection == null) {
            JOptionPane.showMessageDialog(this, "Database is not connected. Configure Oracle JDBC first.");
            return false;
        }
        return true;
    }

    private void addExpense() {
        if (!ready()) return;
        String sql = "INSERT INTO expenses (expense_date, category, description, amount) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(dateField.getText().trim()));
            ps.setString(2, categoryBox.getSelectedItem().toString());
            ps.setString(3, descriptionField.getText().trim());
            ps.setBigDecimal(4, new BigDecimal(amountField.getText().trim()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Expense added.");
            viewMonth();
        } catch (Exception ex) { showError(ex); }
    }

    private void viewMonth() {
        if (!ready()) return;
        try {
            LocalDate first = LocalDate.parse(monthField.getText().trim() + "-01");
            String sql = "SELECT id, expense_date, category, description, amount FROM expenses " +
                    "WHERE expense_date >= ? AND expense_date < ? ORDER BY expense_date, id";
            model.setRowCount(0);
            BigDecimal total = BigDecimal.ZERO;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setDate(1, Date.valueOf(first));
                ps.setDate(2, Date.valueOf(first.plusMonths(1)));
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        BigDecimal amount = rs.getBigDecimal("amount");
                        model.addRow(new Object[]{rs.getInt("id"), rs.getDate("expense_date"),
                                rs.getString("category"), rs.getString("description"), amount});
                        total = total.add(amount);
                    }
                }
            }
            totalLabel.setText("Monthly total: " + total.toPlainString());
        } catch (Exception ex) { showError(ex); }
    }

    private void updateExpense() {
        if (!ready()) return;
        String sql = "UPDATE expenses SET expense_date=?, category=?, description=?, amount=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(dateField.getText().trim()));
            ps.setString(2, categoryBox.getSelectedItem().toString());
            ps.setString(3, descriptionField.getText().trim());
            ps.setBigDecimal(4, new BigDecimal(amountField.getText().trim()));
            ps.setInt(5, Integer.parseInt(idField.getText().trim()));
            int count = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, count > 0 ? "Expense updated." : "No expense found for that ID.");
            viewMonth();
        } catch (Exception ex) { showError(ex); }
    }

    private void deleteExpense() {
        if (!ready()) return;
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM expenses WHERE id=?")) {
            ps.setInt(1, Integer.parseInt(idField.getText().trim()));
            int count = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, count > 0 ? "Expense deleted." : "No expense found for that ID.");
            viewMonth();
        } catch (Exception ex) { showError(ex); }
    }

    private void categoryTotals() {
        if (!ready()) return;
        String sql = "SELECT category, SUM(amount) total FROM expenses " +
                "WHERE expense_date >= ? AND expense_date < ? GROUP BY category ORDER BY category";
        try {
            LocalDate first = LocalDate.parse(monthField.getText().trim() + "-01");
            StringBuilder result = new StringBuilder("Category totals for " + monthField.getText().trim() + ":\n\n");
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setDate(1, Date.valueOf(first));
                ps.setDate(2, Date.valueOf(first.plusMonths(1)));
                try (ResultSet rs = ps.executeQuery()) {
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        result.append(rs.getString("category")).append(": ")
                                .append(rs.getBigDecimal("total")).append('\n');
                    }
                    if (!found) result.append("No expenses found.");
                }
            }
            JOptionPane.showMessageDialog(this, result.toString(), "Category Totals", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) { showError(ex); }
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Operation failed", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExpenseManager().setVisible(true));
    }
}
