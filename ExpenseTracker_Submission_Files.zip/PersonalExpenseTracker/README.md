# Personal Expense Tracker

## Project description (10 lines)
1. Personal Expense Tracker is a Java-based desktop application.
2. It uses Java Swing to provide a graphical user interface.
3. It helps users record and organize daily expenses.
4. Users can enter an expense date, category, description, and amount.
5. JDBC connects the application to an Oracle database.
6. Users can add expenses and view records for a selected month.
7. Existing expense records can be updated by ID.
8. Unwanted expense records can be deleted by ID.
9. The application calculates monthly totals and category-wise totals.
10. The project demonstrates GUI development, JDBC, SQL, and CRUD operations.

## Files
- `ExpenseManager.java` — Java Swing application.
- `expenses.sql` — Oracle table creation script.
- `output.png` — illustrative UI mockup (not captured from a running program).

## Requirements
- JDK 17 or newer
- Oracle Database access and a schema/user
- Oracle JDBC driver (`ojdbc` JAR)

## Setup
1. Run `expenses.sql` as the Oracle database user that will own the table.
2. In `ExpenseManager.java`, replace `HOST`, `1521`, `SERVICE_NAME`, `YOUR_USERNAME`, and `YOUR_PASSWORD` with the details supplied by your database administrator.
3. Add the matching Oracle JDBC driver JAR to the Java project's classpath.
4. Compile and run `ExpenseManager.java`.

The GUI can open without a database connection, but database actions require a working Oracle connection. The included screenshot is an illustrative mockup and must not be described as a verified execution result.
